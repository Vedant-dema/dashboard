﻿DEMA Dashboard — Kalender / Purchase Timetable (context bundle for Codex)

Included paths (relative to this zip root):
- frontend/src/pages/timetable/     — UI: TimetablePage, table, contact drawer, modals, helpers
- frontend/src/store/timetableStore.ts — localStorage persistence, seeds, normalization
- frontend/src/types/timetable.ts  — TimetableEntry, contact profile, offer types
- docs/wireframes/timetable-contact-drawer-wireframe.md — product wireframe

Routes (see repo App.tsx, not in zip): purchase/kalender, purchase/timetable

Use this bundle to draft prompts for features, refactors, or tests on the calendar module.
