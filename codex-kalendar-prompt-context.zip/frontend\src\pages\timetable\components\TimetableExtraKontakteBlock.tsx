import { useEffect, useRef, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import type { TimetableContactPerson, TimetableEntry } from '../../../types/timetable';
import { emptyContactPerson, ensureProfile } from '../contactDrawerFormUtils';
import { normalizePhoneValue } from '../../../features/customers/mappers/customerFormMapper';
import {
  customerModalKontaktInputClass,
  customerModalKontaktLabelClass,
  customerModalKontaktNewBtnClass,
  customerModalKontaktSelectClass,
  customerModalKundeSectionTitleClass,
} from '../contactDrawerFormClasses';

const KONTAKT_COLORS: { dotActive: string; activePill: string }[] = [
  { dotActive: 'bg-slate-500', activePill: 'bg-slate-700' },
  { dotActive: 'bg-slate-500', activePill: 'bg-slate-700' },
  { dotActive: 'bg-slate-500', activePill: 'bg-slate-700' },
  { dotActive: 'bg-slate-500', activePill: 'bg-slate-700' },
  { dotActive: 'bg-slate-500', activePill: 'bg-slate-700' },
  { dotActive: 'bg-slate-500', activePill: 'bg-slate-700' },
  { dotActive: 'bg-slate-500', activePill: 'bg-slate-700' },
  { dotActive: 'bg-slate-500', activePill: 'bg-slate-700' },
];

export type TimetableExtraKontakteBlockProps = {
  contacts: TimetableContactPerson[] | undefined;
  patchDraft: (updater: (prev: TimetableEntry) => TimetableEntry) => void;
  t: (key: string, fallback: string) => string;
  /** Optional id prefix for form fields (overview vs wide form). */
  fieldIdPrefix: string;
  /** Section heading row (title + New) — hide when the parent shell already provides the title (e.g. `OverviewPanel`). */
  showSectionToolbar?: boolean;
  /** When `showSectionToolbar` is false: show only a right-aligned “New” row under the parent title. */
  showEmbeddedAddRow?: boolean;
  /** Section heading class when `showSectionToolbar` is true. */
  sectionTitleClassName?: string;
  /** Parent increments after adding a contact from an external header — focus last pill. */
  appendFocusTick?: number;
};

export function TimetableExtraKontakteBlock({
  contacts,
  patchDraft,
  t,
  fieldIdPrefix,
  showSectionToolbar = true,
  showEmbeddedAddRow = true,
  sectionTitleClassName = customerModalKundeSectionTitleClass,
  appendFocusTick,
}: TimetableExtraKontakteBlockProps) {
  const list = contacts ?? [];
  const [activeIdx, setActiveIdx] = useState(0);
  const appendTickRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    setActiveIdx((i) => {
      if (list.length === 0) return 0;
      return Math.min(Math.max(0, i), list.length - 1);
    });
  }, [list.length]);

  useEffect(() => {
    if (appendFocusTick === undefined) return;
    if (appendFocusTick <= 0) {
      appendTickRef.current = appendFocusTick;
      return;
    }
    if (appendTickRef.current !== appendFocusTick && list.length > 0) {
      setActiveIdx(list.length - 1);
      appendTickRef.current = appendFocusTick;
    }
  }, [appendFocusTick, list.length]);

  const safeIdx = list.length ? Math.min(activeIdx, list.length - 1) : 0;
  const k = list[safeIdx];

  const updateAt = (idx: number, patch: Partial<TimetableContactPerson>) => {
    patchDraft((prev) => {
      const pr = ensureProfile(prev);
      const next = [...(pr.contacts ?? [])];
      const cur = next[idx];
      if (!cur) return prev;
      next[idx] = { ...cur, ...patch };
      return { ...prev, contact_profile: { ...pr, contacts: next } };
    });
  };

  const addContact = () => {
    const newIdx = list.length;
    patchDraft((prev) => {
      const pr = ensureProfile(prev);
      const next = [...(pr.contacts ?? []), emptyContactPerson()];
      return { ...prev, contact_profile: { ...pr, contacts: next } };
    });
    setActiveIdx(newIdx);
  };

  return (
    <div className="flex flex-col gap-3">
      {showSectionToolbar ? (
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
          <div className="min-w-0">
            <p
              className={`${sectionTitleClassName} customers-modal-genz-kunde-col-title--3`}
            >
              {t('customerModalColKontakt', 'Contact person')}
            </p>
          </div>
          <button type="button" onClick={addContact} className={customerModalKontaktNewBtnClass}>
            <Plus className="h-3.5 w-3.5" aria-hidden />
            {t('newCustomerKontaktNewBtn', 'New')}
          </button>
        </div>
      ) : showEmbeddedAddRow ? (
        <div className="flex justify-end">
          <button type="button" onClick={addContact} className={customerModalKontaktNewBtnClass}>
            <Plus className="h-3.5 w-3.5" aria-hidden />
            {t('newCustomerKontaktNewBtn', 'New')}
          </button>
        </div>
      ) : null}

      {list.length === 0 ? (
        <p className="text-xs leading-relaxed text-slate-500">
          {t('timetableContactNoExtraContacts', 'None')}
        </p>
      ) : (
        <>
          <div className="flex flex-wrap gap-1.5">
            {list.map((c, i) => {
              const dc = KONTAKT_COLORS[i % KONTAKT_COLORS.length]!;
              const isActive = i === safeIdx;
              const label =
                c.name || t('newCustomerKontaktDefaultLabel', 'Contact {n}').replace('{n}', String(i + 1));
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setActiveIdx(i)}
                  className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold transition-all ${
                    isActive
                      ? `${dc.activePill} text-white shadow-sm`
                      : 'border border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <span className={`h-2 w-2 rounded-full ${isActive ? 'bg-white/60' : dc.dotActive}`} />
                  <span className="max-w-[10rem] truncate">{label}</span>
                </button>
              );
            })}
          </div>

          {k ? (
            <div className="customers-modal-genz-kontakt-nested-card overflow-hidden rounded-2xl border border-white/60">
              <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50/60 px-3.5 py-2.5">
                <div className="flex min-w-0 items-center gap-2.5">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-700 text-xs font-bold text-white">
                    {k.name
                      ? k.name
                          .split(' ')
                          .map((n) => n[0])
                          .slice(0, 2)
                          .join('')
                          .toUpperCase()
                      : String(safeIdx + 1)}
                  </div>
                  <span className="truncate text-sm font-semibold text-slate-700">
                    {k.name ||
                      t('newCustomerKontaktDefaultLabel', 'Contact {n}').replace('{n}', String(safeIdx + 1))}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    patchDraft((prev) => {
                      const pr = ensureProfile(prev);
                      const next = (pr.contacts ?? []).filter((_, i) => i !== safeIdx);
                      return { ...prev, contact_profile: { ...pr, contacts: next } };
                    });
                  }}
                  className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-500"
                  aria-label={t('newCustomerKontaktRemove', 'Remove contact')}
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden />
                </button>
              </div>

              <div className="space-y-2 p-3">
                <div>
                  <label className={customerModalKontaktLabelClass} htmlFor={`${fieldIdPrefix}-name-${k.id}`}>
                    {t('newCustomerLabelName', 'Name')}
                    {safeIdx === 0 ? <span className="text-red-500"> *</span> : null}
                  </label>
                  <input
                    id={`${fieldIdPrefix}-name-${k.id}`}
                    type="text"
                    value={k.name}
                    onChange={(e) => updateAt(safeIdx, { name: e.target.value })}
                    className={customerModalKontaktInputClass}
                    placeholder={t('newCustomerNamePh', 'First and last name')}
                  />
                </div>

                <div>
                  <label className={customerModalKontaktLabelClass} htmlFor={`${fieldIdPrefix}-rolle-${k.id}`}>
                    {t('newCustomerLabelRolle', 'Function / Role')}
                  </label>
                  <select
                    id={`${fieldIdPrefix}-rolle-${k.id}`}
                    value={k.rolle}
                    onChange={(e) => updateAt(safeIdx, { rolle: e.target.value })}
                    className={customerModalKontaktSelectClass}
                  >
                    <option value="">{t('newCustomerRolleDefault', '— Select role —')}</option>
                    <option value="Geschäftsführer">Geschäftsführer / Geschäftsführerin</option>
                    <option value="Prokurist">Prokurist / Prokuristin</option>
                    <option value="Fuhrparkleiter">Fuhrparkleiter / -leiterin</option>
                    <option value="Disponent">Disponent / Disponentin</option>
                    <option value="Verkaufsleiter">Verkaufsleiter / -leiterin</option>
                    <option value="Einkäufer">Einkäufer / Einkäuferin</option>
                    <option value="Buchhalter">Buchhalter / Buchhalterin</option>
                    <option value="Werkstattleiter">Werkstattleiter / -leiterin</option>
                    <option value="Fahrer">Fahrer / Fahrerin</option>
                    <option value="Sekretariat">Sekretariat / Empfang</option>
                    <option value="Sonstiges">Sonstiges</option>
                  </select>
                </div>

                <div>
                  <label className={customerModalKontaktLabelClass} htmlFor={`${fieldIdPrefix}-tel-${k.id}`}>
                    {t('newCustomerLabelTelefon', 'Phone')}
                  </label>
                  <input
                    id={`${fieldIdPrefix}-tel-${k.id}`}
                    type="tel"
                    value={k.telefon}
                    onChange={(e) => updateAt(safeIdx, { telefon: e.target.value })}
                    onBlur={(e) => updateAt(safeIdx, { telefon: normalizePhoneValue(e.target.value) })}
                    className={customerModalKontaktInputClass}
                    placeholder={t('newCustomerPhPhone', '+49 30 1234567')}
                  />
                </div>

                <div>
                  <label className={customerModalKontaktLabelClass} htmlFor={`${fieldIdPrefix}-handy-${k.id}`}>
                    {t('newCustomerLabelHandy', 'Mobile')}
                  </label>
                  <input
                    id={`${fieldIdPrefix}-handy-${k.id}`}
                    type="tel"
                    value={k.handy}
                    onChange={(e) => updateAt(safeIdx, { handy: e.target.value })}
                    onBlur={(e) => updateAt(safeIdx, { handy: normalizePhoneValue(e.target.value) })}
                    className={customerModalKontaktInputClass}
                    placeholder={t('newCustomerPhMobile', '+49 170 1234567')}
                  />
                </div>

                <div>
                  <label className={customerModalKontaktLabelClass} htmlFor={`${fieldIdPrefix}-email-${k.id}`}>
                    {t('newCustomerLabelEmail', 'E-mail')}
                  </label>
                  <input
                    id={`${fieldIdPrefix}-email-${k.id}`}
                    type="email"
                    value={k.email}
                    onChange={(e) => updateAt(safeIdx, { email: e.target.value })}
                    className={customerModalKontaktInputClass}
                    placeholder={t('newCustomerPhEmail', 'name@company.com')}
                  />
                </div>

                <div>
                  <label className={customerModalKontaktLabelClass} htmlFor={`${fieldIdPrefix}-web-${k.id}`}>
                    {t('customersLabelWebsite', 'Website')}
                  </label>
                  <input
                    id={`${fieldIdPrefix}-web-${k.id}`}
                    type="text"
                    value={k.website}
                    onChange={(e) => updateAt(safeIdx, { website: e.target.value })}
                    className={customerModalKontaktInputClass}
                    placeholder={t('newCustomerPhWebsite', 'www.example.com')}
                    inputMode="url"
                    autoComplete="url"
                  />
                </div>

                <div>
                  <label className={customerModalKontaktLabelClass} htmlFor={`${fieldIdPrefix}-bem-${k.id}`}>
                    {t('newCustomerLabelKontaktBemerkung', 'Note')}
                  </label>
                  <textarea
                    id={`${fieldIdPrefix}-bem-${k.id}`}
                    value={k.bemerkung}
                    onChange={(e) => updateAt(safeIdx, { bemerkung: e.target.value })}
                    rows={2}
                    className={`${customerModalKontaktInputClass} min-h-[60px] resize-y py-2`}
                  />
                </div>
              </div>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
